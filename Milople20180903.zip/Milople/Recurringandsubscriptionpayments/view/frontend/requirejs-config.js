var config = {
    "map": {
        "*": {            
            "Magento_Authorizenet/js/view/payment/method-renderer/authorizenet-directpost": "Milople_Recurringandsubscriptionpayments/js/authorizenet-directpost"
        }
    }
}; 