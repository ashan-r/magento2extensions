<?php
namespace Mageplaza\Affiliate\Block\Account\Withdraw;

/**
 * Payment method form base block
 */
class Methods extends \Mageplaza\Affiliate\Block\Account\Withdraw
{
}
